
# SALOME LANDEROS SALAZAR IA 6-7PM
class Nodo:
    def __init__(self, valor):
        self.valor = valor
        self.izquierda = None
        self.derecha = None
    